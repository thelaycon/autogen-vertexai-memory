"""VertexAI Memory integration for Autogen agents."""

__version__ = "0.1.0"

from autogen_vertexai_memory.memory import VertexaiMemory

__all__ = ["VertexaiMemory"]
