"""VertexAI Memory integration for Autogen agents."""

__version__ = "0.2.0"

from .__vertexai_memory import VertexaiMemory

__all__ = ["VertexaiMemory"]
